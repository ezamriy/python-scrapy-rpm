EXTENSIONS = [
    'scrapy.tests.test_cmdline.extensions.TestExtension'
]

TEST1 = 'default'
